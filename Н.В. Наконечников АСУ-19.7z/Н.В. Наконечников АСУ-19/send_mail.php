<?php
// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Get the form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];
    
    // Set the recipient email address(es)
    $to = 'recipient@example.com';
    
    // Set the email subject
    $subject = 'New message from ' . $name;
    
    // Build the email message
    $body = "Имя: $name\n\n";
    $body .= "Почта: $email\n\n";
    $body .= "Сообщение:\n$message";
    
    // Set the email headers
    $headers = "From: $email\r\n";
    $headers .= "Reply-To: $email\r\n";
    
    // Send the email
    if (mail($to, $subject, $body, $headers)) {
        // If the email was sent successfully, redirect to a success page
        header('Location: success.php');
        exit;
    } else {
        // If the email failed to send, display an error message
        echo 'There was an error sending your message. Please try again later.';
    }
}
?>
